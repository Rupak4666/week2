﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Rupak Paudel
    301399650 */

namespace rupakpaudel301399650_lab2_3
{
   public class Evaluation
{
    private int id;
    private EvaluationType type;
    private string name;
    private DateTime dueDate;
    private byte weight;
    private double grade;
    private Course course;
    private List<Task> tasks;
    private string textFile;

    public Evaluation(Course course, EvaluationType type, byte weight, string name)
    {
        this.course = course;
        this.type = type;
        this.name = name;
        this.weight = weight;
        dueDate = DateTime.MaxValue;
        grade = 0;
        tasks = new List<Task>();
    }

    public EvaluationType Type
    {
        get {
                return type;
               
            }
          private  set { type = value; }
    }

    public string Name
    {
        get { return name; }
            set { name = value; }
    }

    public DateTime DueDate
    {
        get { return dueDate; }
        set { dueDate = value; }
    }

    public byte Weight
    {
        get { return weight; }
            set { weight = value; } 
    }

    public double Grade
    {
        get { return grade; }
        set { grade = value; }
    }

    public Course Course
    {
        get { return course; } 
            set { course = value; }
    }

    public List<Task> Tasks
    {
        get { return tasks; }

              
    }

    public string TextFile
    {
        get { return textFile; }
        set { textFile = value; }
    }

    public int Id
    {
        get { return id; }
            set { id = value; }
    }

    public void AddTask(string description)
    {
        Task task = TaskManager.CreateTask(description);
        tasks.Add(task);
    }

    public string TasksToString()
    {
        string result = "";
        foreach (Task task in tasks)
        {
            result += task.ToString() + "\n";
        }
        return result;
    }

    public override string ToString()
    {
        return $"{type} - {name} (Weight: {weight})";
    }
}
}
