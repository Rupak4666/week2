﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace rupakpaudel301399650_lab2_3
{
    public class Course
    {
        private string name;
        private string code;
        private string semester;
        private int id;
        private List<Evaluation> evaluations;
        private List<Task> tasks;

        public Course(string name, string code, string semester, int id)
        {
            this.name = name;
            this.code = code;
            this.semester = semester;
            this.id = id;
            evaluations = new List<Evaluation>();
            tasks = new List<Task>();
        }

        public string Code
        {
            get { return code; }
        }

        public string Semester
        {
            get { return semester; }
        }

        public int Id
        {
            get { return id; }
        }

        public string Name
        {
            get { return name; }
        }

        public double Grade
        {
            get
            {
                double total = 0;
                foreach (Evaluation evaluation in evaluations)
                {
                    total += evaluation.Weight * evaluation.Grade;
                }
                return total;
            }
        }

        public List<Evaluation> Evaluations
        {
            get
            { 
                return evaluations;
            }
        }

        public List<Task> Tasks
        {
            get
            {
                return tasks; 
            }
        }

        public void AddEvaluation(EvaluationType type, byte weight, string name)
        {
            Evaluation evaluation = new Evaluation(this, type, weight, name);
            evaluations.Add(evaluation);
        }

        public void AddTask(string description)
        {
            Task task = TaskManager.CreateTask(description);
            tasks.Add(task);
        }

        public string TasksToString()
        {
            string result = "";
            foreach (Task task in tasks)
            {
                result += task.ToString() + "\n";
            }
            return result;
        }

        public override string ToString()
        {
            return $"Course {code} - {name} ({semester})";
        }
    }
}
