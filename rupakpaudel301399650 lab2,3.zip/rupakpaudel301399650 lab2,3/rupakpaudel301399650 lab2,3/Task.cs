﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Rupak Paudel
    301399650 */

namespace rupakpaudel301399650_lab2_3
{
    public struct Task
    {
        public string Description;
        public DateTime DueDate;
        private bool done;

        public Task(string description)
        {
            Description = description;
            DueDate = DateTime.MaxValue;
            done = false;
        }

        public bool Done
        {
            get { return done; }
            set { done = value; }
        }

        public override string ToString()
        {
            return $"{Description} ({DueDate.ToShortDateString()})";
        }
    }
}
