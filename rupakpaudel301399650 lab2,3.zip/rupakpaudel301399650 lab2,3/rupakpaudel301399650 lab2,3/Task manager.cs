﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Rupak Paudel
    301399650 */

namespace rupakpaudel301399650_lab2_3
{
    public class TaskManager
    {
        private static List<Task> tasks;

        static TaskManager()
        {
            tasks = new List<Task>();
        }

        public static List<Task> Tasks
        {
            get { return tasks; }
        }

        public static Task CreateTask(string description)
        {
            Task task = new Task(description);
            tasks.Add(task);
            return task;
        }

        public static string AllTasksToString()
        {
            string result = "";
            foreach (Task task in tasks)
            {
                result += task.ToString() + "\n";
            }
            return result;
        }
    }
}
