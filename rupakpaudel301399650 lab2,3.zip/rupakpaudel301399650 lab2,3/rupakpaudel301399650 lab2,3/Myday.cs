﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Rupak Paudel
    301399650 */

namespace rupakpaudel301399650_lab2_3
{
    public class MyDay
    {
        private static MyDay currentDay;
        private List<Task> todaysTasks;
        private DateTime date;

        private MyDay()
        {
            date = DateTime.Now;
            todaysTasks = new List<Task>();
        }

        public static MyDay NewDay()
        {
            if (currentDay == null || currentDay.date != DateTime.Now)
            {
                currentDay = new MyDay();
            }
            return currentDay;
        }

        public List<Task> TodaysTasks
        {
            get { return todaysTasks; }
        }

        public void AddDayTask(Task task)
        {
            todaysTasks.Add(task);
        }

        public override string ToString()
        {
            string result = "";
            foreach (Task task in todaysTasks)
            {
                result += task.ToString() + "\n";
            }
            return result;
        }
    }
}
