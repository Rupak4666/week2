﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

   /* Rupak Paudel
    301399650 */


namespace rupakpaudel301399650_lab2_3
{
    public enum EvaluationType
    {
        Assignment,
        Quiz,
        Test
    }
}
