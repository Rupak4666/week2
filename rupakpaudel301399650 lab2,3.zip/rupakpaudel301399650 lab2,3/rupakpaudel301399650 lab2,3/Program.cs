﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Rupak Paudel
    301399650 */

namespace rupakpaudel301399650_lab2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Course course1 = new Course("Introduction to Programming", "CSC101", "Fall", 0);
            Course course2 = new Course("Data Structures and Algorithms", "CSC201", "Fall", 1);
            Console.WriteLine(course1.ToString());
            Console.WriteLine(course2.ToString());


            course1.AddEvaluation(EvaluationType.Assignment, 20, "Assignment 1");
            course1.AddEvaluation(EvaluationType.Assignment, 20, "Assignment 2");
            course1.AddEvaluation(EvaluationType.Quiz, 10, "Quiz 1");
            course1.AddEvaluation(EvaluationType.Test, 50, "Midterm Exam");


            course2.AddEvaluation(EvaluationType.Assignment, 30, "Assignment 1");
            course2.AddEvaluation(EvaluationType.Assignment, 30, "Assignment 2");
            course2.AddEvaluation(EvaluationType.Assignment, 30, "Assignment 3");
            course2.AddEvaluation(EvaluationType.Test, 10, "Final Exam");

            Evaluation firstEvaluation = course1.Evaluations[3];
            firstEvaluation.DueDate = new DateTime(2023, 9, 15);
            firstEvaluation.Grade = 85;
           
            Evaluation secondEvaluation = course2.Evaluations[1];
            secondEvaluation.DueDate = new DateTime(2024, 5, 30);
            secondEvaluation.Grade = 60;

            Console.WriteLine(firstEvaluation.ToString());
            Console.WriteLine(firstEvaluation.DueDate);
            Console.WriteLine(firstEvaluation.Grade);
            Console.WriteLine(secondEvaluation.ToString());
            Console.WriteLine(secondEvaluation.DueDate);
            Console.WriteLine(secondEvaluation.Grade);
            
           
            
        
    
            Task task1 = TaskManager.CreateTask("Buy a new laptop");
            course1.Tasks.Add(task1);
            task1.DueDate = new DateTime(2024, 5, 31);

            Task task2 = TaskManager.CreateTask("Submit assignment 1");
            course1.Tasks.Add(task2);
            task2.DueDate = new DateTime(2024, 6, 02);


            Task task3 = TaskManager.CreateTask("Study for mi");
            course1.Tasks.Add(task3);
            task3.DueDate = new DateTime(2024, 7, 02);


            Console.WriteLine(task1.ToString());
            Console.WriteLine(task1.DueDate);
            Console.WriteLine(task2.ToString());
            Console.WriteLine(task2.DueDate);
            Console.WriteLine(task3.ToString());
            Console.WriteLine(task3.DueDate);
            
        }
    }
}